import requests
import json

def print_json_data(url):
    response = requests.get(url)
    data = response.json()
    print(json.dumps(data, indent=4))

def modify_team_data(url):
    response = requests.get(url)
    data = response.json()

    newData = data 
    newData['team_id'] = '8175'
    newData['members'][0]['name'] = 'Luonghotrongnghia'
    newData['members'][1]['name'] = 'Phamconglap'
    newData['members'][0]['student_id'] = '21522735'
    newData['members'][1]['student_id'] = '21522281'

    print(json.dumps(newData, indent=4))

def print_keyword_info(url):
    response = requests.get(url)
    response.raise_for_status()
    data = response.json()

    num_keywords = len(data)
    keyword_list = list(data.keys())

    print(f"Số keyword: {num_keywords}")
    print(f"Danh sách keyword: {', '.join(keyword_list)}")

def print_default_member_count(url):
    response = requests.get(url)
    data = response.json()

    members = data.get("members", [])
    num_members = len(members)

    print(f"Số thành viên mặc định của nhóm: {num_members}")

# Câu 1: In dữ liệu JSON
print_json_data('https://mocki.io/v1/641d1b89-50ca-401a-9c6c-e149d4a6e562')

# Câu 2: In ra số keyword và danh sách keyword có trong thông tin 1 nhóm
print_keyword_info('https://mocki.io/v1/641d1b89-50ca-401a-9c6c-e149d4a6e562')

# Câu 3: In ra số thành viên mặc định của nhóm
print_default_member_count('https://mocki.io/v1/641d1b89-50ca-401a-9c6c-e149d4a6e562')

# Câu 4: Sửa đổi dữ liệu nhóm
modify_team_data('https://mocki.io/v1/641d1b89-50ca-401a-9c6c-e149d4a6e562')